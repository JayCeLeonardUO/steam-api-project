print("cs670 is now in the project")
